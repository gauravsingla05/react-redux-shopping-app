module.exports ={
    secret:process.env.SECRET,
    admin_email: process.env.ADMIN_EMAIL,
    admin_password:process.env.ADMIN_PASSWORD,
    razorpay_webhook_secret:process.env.RAZORPAY_WEBHOOK_SECRET
    }
    