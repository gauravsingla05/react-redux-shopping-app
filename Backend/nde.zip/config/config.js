module.exports = {
    secret: 'qpalskdjfhgtyrueibvnxjj4676'
  };

//   module.exports = {
//   HOST: 'localhost',
//   USER: 'root',
//   PASSWORD:'12345678',
//   DB: 'shopy'
// };

module.exports = {
  HOST: 'localhost',
  USER: 'autobyte_root',
  PASSWORD:'Mock@tests@061',
  DB: 'autobyte_shoppy'
};

